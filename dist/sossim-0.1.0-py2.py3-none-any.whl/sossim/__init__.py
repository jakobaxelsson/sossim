"""
The `sossim` package provides a simulator of transportation system.
It is intended to be used for experimenting with different ways of designing systems-of-systems (SoS).
It can be executed both from the command line and as an interactive simulation in a browser.
"""